import React, {useState} from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableHighlight,
  ScrollView,
  Image,
} from 'react-native';

function BookDemo({navigation}) {
  const [name, setName] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('+92'); // Start with +92
  const [address, setAddress] = useState('');

  const handleChangePhoneNumber = text => {
    // Allow only digits and +
    if (/^\+92\d+$/.test(text)) {
      setPhoneNumber(text);
    } else if (text.length < 13) {
      setPhoneNumber(text.replace(/[^0-9+]/g, ''));
    }
  };

  const handleBookDemo = () => {
    // Extract digits for backend
    const digitsForBackend = phoneNumber.substring(3);
    console.log('Booking a demo for:', name, digitsForBackend, address);
    setName(''), setPhoneNumber('+92'), setAddress('');
  };

  return (
    <ScrollView>
      <View className="flex-1 h-screen justify-around bg-[#6755A4]">
        <View>
          <Image
            source={require('../assets/logo2.png')}
            className="mt-10 mx-auto object-contain w-40 h-60 rounded-lg"
          />
        </View>

        {/* Form */}
        <View className="p-5 mt-5 mx-5">
          <TextInput
            className="border-[#3FC4E0] border-b-2 text-white py-2 text-lg px-2 mb-4"
            onChangeText={text => setName(text)}
            value={name}
            placeholder="Full Name"
            placeholderTextColor={'white'}
          />

          {/* Phone Number Input with +92 prefix */}
          <TextInput
            className="border-[#3FC4E0] border-b-2 text-white py-2 text-lg px-2 mb-4"
            onChangeText={handleChangePhoneNumber}
            value={phoneNumber}
            keyboardType="numeric"
            maxLength={13}
            placeholder="Phone Number (+92)"
            placeholderTextColor={'white'}
          />

          <TextInput
            className="border-[#3FC4E0] border-b-2 text-white py-2 text-lg px-2 mb-4"
            onChangeText={text => setAddress(text)}
            value={address}
            placeholder="Address"
            placeholderTextColor={'white'}
          />

          <TouchableHighlight
            className="bg-white py-2 px-4 w-52 mx-auto rounded-md max-h-fit"
            onPress={handleBookDemo}
            disabled={phoneNumber.length !== 13} // Disable button if phone number is invalid
          >
            <Text className="text-[#6755A4] text-xl text-center font-bold">
              Book Now
            </Text>
          </TouchableHighlight>
        </View>

        {/* Already a user */}
        <View className="p-7">
          <Text className="text-[#3FC4E0] text-center mt-4 mb-2 text-xl">
            Already a user?
          </Text>
          <TouchableHighlight
            className="border-white border-2 rounded-md py-2 px-4 w-52 mx-auto"
            onPress={() => navigation.goBack()}>
            <Text className="text-white text-xl text-center font-bold">
              Go back
            </Text>
          </TouchableHighlight>
        </View>
      </View>
    </ScrollView>
  );
}

export default BookDemo;
