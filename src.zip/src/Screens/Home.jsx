import React, {useEffect, useState, useMemo, useCallback} from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  Image,
  ActivityIndicator,
  RefreshControl,
  StyleSheet,
} from 'react-native';
import {useSelector, useDispatch} from 'react-redux';
import {
  addToCart,
  removeFromCart,
  searchItems,
  setSelectedProduct,
  showData,
  updateQuantity,
} from '../Features/ParchiSlice';
import Search from '../Components/Search';
import SingleItem from '../Components/ItemModal';
import AddIcon from 'react-native-vector-icons/AntDesign';
import MinusIcon from 'react-native-vector-icons/AntDesign';

const PAGE_SIZE = 10;

const Home = () => {
  const {products, loading, error, searchData} = useSelector(
    state => state.app,
  );
  const {userId, logo} = useSelector(state => state.pin);
  const dispatch = useDispatch();
  const [showSingleItem, setShowSingleItem] = useState(false);
  const [activeFilter, setActiveFilter] = useState('all products');
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsToShow, setItemsToShow] = useState([]);
  const [showLoadMoreButton, setShowLoadMoreButton] = useState(false);
  const [refreshing, setRefreshing] = useState(false);

  const cartItems = useSelector(state => state.app.cartItems);

  const onRefresh = useCallback(() => {
    setRefreshing(true);
    dispatch(showData(userId))
      .then(() => {
        setCurrentPage(1);
        setItemsToShow([]);
        setShowLoadMoreButton(false);
      })
      .finally(() => setRefreshing(false));
  }, [dispatch, userId]);

  useEffect(() => {
    dispatch(showData(userId));
    setCurrentPage(1);
    setItemsToShow([]);
    setShowLoadMoreButton(false);
  }, [dispatch, userId]);

  useEffect(() => {
    if (!loading && filteredProducts.length > itemsToShow.length) {
      setShowLoadMoreButton(true);
    } else {
      setShowLoadMoreButton(false);
    }
  }, [loading, itemsToShow, filteredProducts]);

  useEffect(() => {
    if (!loading && itemsToShow.length === 0 && filteredProducts.length > 0) {
      setItemsToShow(filteredProducts.slice(0, PAGE_SIZE));
    }
  }, [loading, itemsToShow, filteredProducts]);

  const isItemInCart = itemId => cartItems.some(item => item.id === itemId);

  const handleChange = text => {
    dispatch(searchItems(text));
  };

  const handleFilterClick = filter => {
    setActiveFilter(filter);
    setCurrentPage(1);
    setItemsToShow([]);
    setShowLoadMoreButton(false);
  };

  const categories = useMemo(() => {
    const uniqueCategories = [
      ...new Set(products.map(product => product.Category)),
    ];
    return ['All Products', ...uniqueCategories];
  }, [products]);

  const filteredProducts = useMemo(() => {
    if (!products) return [];
    if (activeFilter === 'all products') return products;
    return products.filter(
      product => product.Category.toLowerCase() === activeFilter,
    );
  }, [products, activeFilter]);

  const updateCartQuantity = (productId, quantity) => {
    if (quantity < 1) {
      dispatch(removeFromCart(productId));
    }

    dispatch(updateQuantity({productId, quantity}));
  };

  const selectedItem = itemId => {
    dispatch(setSelectedProduct(itemId));
    setShowSingleItem(true);
  };

  return (
    <ScrollView
      refreshControl={
        <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
      }>
      {showSingleItem && (
        <SingleItem onClose={() => setShowSingleItem(false)} />
      )}
      <View>
        <Search search={handleChange} />
      </View>
      <View className="my-2">
        <Image
          source={{uri: `data:image/jpeg;base64,${logo}`}}
          className="mx-auto w-screen h-44 rounded-lg object-fill"
        />
      </View>
      <View className="flex-row mx-2 mb-7 overflow-x-auto justify-start scrollbar-hide">
        <ScrollView horizontal={true} showsHorizontalScrollIndicator={false}>
          {categories.map(filter => (
            <TouchableOpacity
              key={filter}
              onPress={() => handleFilterClick(filter.toLowerCase())}
              className={
                activeFilter.toLowerCase() === filter.toLowerCase()
                  ? `rounded-full px-4 py-2 mx-1 shadow-sm bg-[#6755A4] text-white`
                  : `rounded-full px-4 py-2 mx-1 shadow-sm bg-white text-gray-700`
              }>
              <Text
                className={
                  activeFilter.toLowerCase() === filter.toLowerCase()
                    ? `font-bold text-sm text-white`
                    : `font-bold text-sm text-[#6755A4]`
                }>
                {filter}
              </Text>
            </TouchableOpacity>
          ))}
        </ScrollView>
      </View>
      <View className="flex-row flex-wrap text-center justify-between p-5 gap-5 bg-white">
        {loading && itemsToShow.length === 0 && (
          <ActivityIndicator
            size={300}
            color={'#6755A4'}
            animating={true}
            className="flex justify-center items-center"
          />
        )}
        {error && <Text>Error: {error.message}</Text>}
        {filteredProducts.length > 0 &&
          filteredProducts
            .filter(ele => {
              if (searchData.length === 0) {
                return ele;
              } else {
                return ele.Name.toLowerCase().includes(
                  searchData.toLowerCase(),
                );
              }
            })
            .map(item => (
              <TouchableOpacity
                onPress={() => selectedItem(item.id)}
                key={item.id}
                className="rounded-lg max-h-fit"
                style={{width: 150}}>
                <View className="rounded-xl border border-gray-300 p-7 relative">
                  <Image
                    source={{uri: `data:image/jpeg;base64,${item.Image}`}}
                    style={{width: 100, height: 100}}
                    resizeMode="contain"
                  />
                  {isItemInCart(item.id) ? (
                    <View style={styles.view}>
                      <TouchableOpacity
                        style={{marginRight: 5, paddingHorizontal: 5}}
                        onPress={() =>
                          updateCartQuantity(
                            item.id,
                            cartItems.find(cartItem => cartItem.id === item.id)
                              .quantity - 1,
                          )
                        }>
                        <Text style={styles.sign}>−</Text>
                      </TouchableOpacity>
                      <Text style={styles.count}>
                        {cartItems.find(cartItem => cartItem.id === item.id)
                          ?.quantity || 0}
                      </Text>
                      <TouchableOpacity
                        style={{marginLeft: 5, paddingHorizontal: 5}}
                        onPress={() =>
                          updateCartQuantity(
                            item.id,
                            cartItems.find(cartItem => cartItem.id === item.id)
                              .quantity + 1,
                          )
                        }>
                        <Text style={styles.sign}>+</Text>
                      </TouchableOpacity>
                    </View>
                  ) : (
                    <TouchableOpacity
                      onPress={() => {
                        dispatch(addToCart(item));
                      }}
                      className="absolute bottom-[0] right-[-15]">
                      <AddIcon name="pluscircle" color="#6755A4" size={30} />
                    </TouchableOpacity>
                  )}
                </View>
                <View className="flex-grow">
                  <Text className="font-medium text-black pl-2 text-lg ">
                    Rs.{item.Unit_Price}
                  </Text>
                  <Text className="text-base pl-2 mb-2 text-black">
                    {item.Name}
                  </Text>
                </View>
              </TouchableOpacity>
            ))}
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  view: {
    flexDirection: 'row',
    alignSelf: 'flex-end',
    alignItems: 'center',
    justifyContent: 'center',
    position: 'absolute',
    marginTop: 130,
    backgroundColor: '#6755A4',
    borderRadius: 100,
  },
  sign: {
    fontSize: 25,
    color: 'white',
  },
  count: {
    fontSize: 15,
    fontWeight: 'bold',
    color: 'white',
  },
});

export default Home;
