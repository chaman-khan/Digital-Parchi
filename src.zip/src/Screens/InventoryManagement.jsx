import React, {useEffect, useState, useMemo, useCallback} from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  Image,
  ActivityIndicator,
  RefreshControl,
  Alert,
  StyleSheet,
} from 'react-native';
import {useSelector, useDispatch} from 'react-redux';
import {
  searchItems,
  setSelectedProduct,
  showData,
} from '../Features/ParchiSlice';
import Search from '../Components/Search';
import SingleItem from '../Components/ItemModal';
import EditIcon from 'react-native-vector-icons/Feather';

const PAGE_SIZE = 10;
const InventoryManagement = ({navigation}) => {
  const {products, loading, error, searchData} = useSelector(
    state => state.app,
  );
  const {userId, logo} = useSelector(state => state.pin);
  const [showSingleItem, setShowSingleItem] = useState(false);
  const [activeFilter, setActiveFilter] = useState('all products');
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsToShow, setItemsToShow] = useState([]);
  const [showLoadMoreButton, setShowLoadMoreButton] = useState(false); // State to control button visibility
  const [refreshing, setRefreshing] = useState(false);
  const dispatch = useDispatch();
  const [count, setCount] = useState(1);

  const cartItems = useSelector(state => state.app.cartItems);
  const onRefresh = useCallback(() => {
    setRefreshing(true);

    // Fetch data on refresh
    dispatch(showData(userId))
      .then(() => {
        setCurrentPage(1);
        setItemsToShow([]);
        setShowLoadMoreButton(false);
      })
      .finally(() => setRefreshing(false));
  }, [dispatch, userId]);

  useEffect(() => {
    // Fetch data on mount regardless of activeCategory
    dispatch(showData(userId));
    setCurrentPage(1);
    setItemsToShow([]);
    setShowLoadMoreButton(false);
  }, []);

  useEffect(() => {
    // Display the Load More button only when the initial data is loaded
    if (!loading && filteredProducts.length > itemsToShow.length) {
      setShowLoadMoreButton(true);
    } else {
      setShowLoadMoreButton(false);
    }
  }, [loading, itemsToShow, filteredProducts]);

  useEffect(() => {
    // Handle changes in itemsToShow
    if (!loading && itemsToShow.length === 0 && filteredProducts.length > 0) {
      // If itemsToShow is empty, set the first page of items
      setItemsToShow(filteredProducts.slice(0, PAGE_SIZE));
    }
  }, [loading, itemsToShow, filteredProducts]);

  const handleChange = text => {
    dispatch(searchItems(text));
  };

  const handleFilterClick = filter => {
    setActiveFilter(filter);
    setCurrentPage(1);
    setItemsToShow([]); // Clear the items to show when the filter changes
    setShowLoadMoreButton(false); // Hide the button when filters change
  };

  const categories = useMemo(() => {
    const uniqueCategories = Array.from(
      new Set(products.map(product => product.Category)),
    );
    return ['All Products', ...uniqueCategories];
  }, [products]);

  const filteredProducts = useMemo(() => {
    if (!products) return [];
    if (activeFilter === 'all products') return products;
    return products.filter(
      product => product.Category.toLowerCase() === activeFilter,
    );
  }, [products, activeFilter]);

  return (
    <View>
      <View
        style={{
          width: '100%',
          height: 60,
          backgroundColor: '#6755A4',
          alignItems: 'center',
          justifyContent: 'center',
        }}>
        <Text style={{color: 'white', fontSize: 20}}>Inventory Management</Text>
      </View>
      <ScrollView
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
        }>
        {/* refresh */}

        {/* modal */}
        {showSingleItem && (
          <SingleItem onClose={() => setShowSingleItem(false)} />
        )}

        {/* search Bar */}
        <View>
          <Search search={handleChange} />
        </View>

        {/* Hero Banner */}
        <View className="my-2">
          <Image
            source={{uri: `data:image/jpeg;base64,${logo}`}}
            className="mx-auto w-screen h-44 rounded-lg object-fill"
          />
        </View>

        {/* filters */}
        <View className="flex-row mx-2 mb-7 overflow-x-auto justify-start scrollbar-hide">
          <ScrollView horizontal={true} showsHorizontalScrollIndicator={false}>
            {categories.map(filter => (
              <TouchableOpacity
                key={filter}
                onPress={() => handleFilterClick(filter.toLowerCase())}
                className={
                  activeFilter.toLowerCase() === filter.toLowerCase()
                    ? `rounded-full px-4 py-2 mx-1 shadow-sm bg-[#6755A4] text-white`
                    : `rounded-full px-4 py-2 mx-1 shadow-sm bg-white text-gray-700`
                }>
                <Text
                  className={
                    activeFilter.toLowerCase() === filter.toLowerCase()
                      ? `font-bold text-sm text-white`
                      : `font-bold text-sm text-[#6755A4]`
                  }>
                  {filter}
                </Text>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>

        {/* Products */}
        <View className="flex-row flex-wrap text-center justify-between p-5 gap-5 bg-white">
          {loading && itemsToShow.length === 0 && (
            <ActivityIndicator
              size={300}
              color={'#6755A4'}
              animating={true}
              className="flex justify-center items-center"
            />
          )}
          {error && <Text>Error: {error.message}</Text>}
          {filteredProducts.length > 0 &&
            filteredProducts
              .filter(ele => {
                if (searchData.length === 0) {
                  return ele;
                } else {
                  return ele.Name.toLowerCase().includes(
                    searchData.toLowerCase(),
                  );
                }
              })
              .map(item => (
                <TouchableOpacity
                  activeOpacity={1}
                  key={item.id}
                  className="rounded-lg max-h-fit"
                  style={{width: 150}}>
                  <View className="rounded-xl border border-gray-300 p-7 relative">
                    <Image
                      source={{uri: `data:image/jpeg;base64,${item.Image}`}}
                      style={{width: 100, height: 100}}
                      resizeMode="contain"
                    />
                    <TouchableOpacity
                      onPress={() => navigation.navigate('EditScreen', {item})}
                      className="absolute bottom-[0] right-[-15]"
                      style={{
                        backgroundColor: '#6755A4',
                        borderRadius: 50,
                        padding: 5,
                      }}>
                      <EditIcon name="edit-2" color="white" size={20} />
                    </TouchableOpacity>
                  </View>
                  <View className="flex-grow">
                    <Text className="font-medium text-black pl-2 text-lg ">
                      Rs.{item.Unit_Price}
                    </Text>
                    <Text className="text-base pl-2 mb-2 text-black">
                      {item.Name}
                    </Text>
                  </View>
                </TouchableOpacity>
              ))}
        </View>
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  view: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    // height: 30,
    // marginHorizontal: 10,
    // marginTop: 10,
    backgroundColor: '#6755A4',
    borderRadius: 100,
  },
  sign: {
    fontSize: 25,
    color: 'white',
  },
  count: {
    fontSize: 15,
    fontWeight: 'bold',
    color: 'white',
  },
});

export default InventoryManagement;
