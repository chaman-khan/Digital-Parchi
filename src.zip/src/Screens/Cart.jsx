import React, {useEffect, useState} from 'react';
import {
  Text,
  View,
  Image,
  TouchableOpacity,
  FlatList,
  Button,
} from 'react-native';
import {BluetoothEscposPrinter} from 'react-native-bluetooth-escpos-printer'; // Assuming compatibility with printing requirements
import {useSelector, useDispatch} from 'react-redux';
import {
  removeFromCart,
  updateQuantity,
  clearCart,
  cartData,
  offlineCart,
  clearCartOffline,
} from '../Features/ParchiSlice';
// TODO: Replace placeholder logo path with correct value
// import logo from "../assets/logo3.png";
import CrossIcon from 'react-native-vector-icons/Entypo';
import NetInfo from '@react-native-community/netinfo';

const Cart = () => {
  const cartItems = useSelector(state => state.app.cartItems);
  const offlineCartItem = useSelector(state => state.app.offlineCartItems);
  const {userId, logo} = useSelector(state => state.pin);
  const dispatch = useDispatch();

  const [isOnline, setIsOnline] = useState(false); // Track online/offline status
  const [offlineBills, setOfflineBills] = useState([]); // Store offline bills in separate state

  // Track if a print request is ongoing to prevent concurrent execution
  const [isPrinting, setIsPrinting] = useState(false);
  console.log('offline cart ');
  console.log(offlineCartItem.length);
  React.useEffect(() => {
    const unsubscribe = NetInfo.addEventListener(state => {
      console.log('state');
      console.log(state);
      setIsOnline(state.isConnected);
    });
    return () => {
      unsubscribe();
    };
  }, []);
  const handleNetworkChange = state => {
    setIsOnline(state.isConnected);
  };
  useEffect(() => {
    const netInfoSubscription = NetInfo.addEventListener(handleNetworkChange);
    return () => {
      netInfoSubscription && netInfoSubscription();
    };
  }, []);

  useEffect(() => {
    if (isOnline && offlineCartItem.length > 0) {
      console.log('saing offline data ');
      const cartBill = offlineCartItem.map((item, index) => ({
        id: item.id,
        Name: item.Name,
        Quantity: item.quantity,
        Price: item.Unit_Price,
      }));
      dispatch(
        cartData({products: cartBill, status: 'Save', businessId: userId}),
      );
      dispatch(clearCartOffline());
    }
  }, [isOnline, offlineCartItem]);
  // useEffect(() => {
  //   // Clear offline bills after successful online sync
  //   const handleOfflineSync = async () => {
  //     if (isOnline && offlineCartItem.length > 0) {
  //       // Dispatch offline bills to backend in a controlled manner, with proper
  //       // error handling and retry logic:
  //       for (const bill of offlineCartItem) {
  //         try {
  //           await dispatch(cartData({ products: bill, status: 'OfflineSync', businessId: userId }));
  //         } catch (error) {
  //           console.error('Error syncing offline bill:', error);
  //           // Implement retry mechanism or store failed bills separately
  //         }
  //       }
  //       await clearOfflineData(); // Clear storage after successful sync
  //       setOfflineBills([]); // Clear state
  //     }
  //   };
  //   handleOfflineSync();
  // }, [isOnline, offlineBills]); // Re-run on online status or bill changes

  // remove items from cart
  const handleRemoveFromCart = productId => {
    dispatch(removeFromCart(productId));
  };

  // updating quantity
  const updateCartQuantity = (productId, quantity) => {
    // Ensure quantity stays above 0
    if (quantity < 1) {
      dispatch(removeFromCart(productId));
      return;
    }

    dispatch(updateQuantity({productId, quantity}));
  };

  // cart items
  const renderCartItem = ({item}) => (
    <View className="items-center my-2 flex-row bg-white shadow-lg shadow-gray-400 rounded-lg py-4 px-2">
      <Text className="text-xl font-extrabold text-[#6755A4] pr-3">
        {item.quantity + 'x'}
      </Text>
      <Image
        source={{uri: `data:image/jpeg;base64,${item.Image}`}}
        className="mr-5"
        style={{width: 60, height: 80, objectFit: 'contain'}}
      />
      <View className="flex-1">
        <Text className="text-xl text-black font-bold">{item.Name}</Text>
        <Text className="text-[#6755A4] font-semibold text-lg my-1">
          Rs.{item.totalPrice.toFixed(2)}
        </Text>
        <View className="flex-row items-center justify-center shadow-2xl shadow-[#6755A4] bg-white rounded-lg w-28">
          <TouchableOpacity
            className="mr-2"
            onPress={() => updateCartQuantity(item.id, item.quantity - 1)}>
            <Text className="text-4xl text-[#6755A4] font-bold pt-1">−</Text>
          </TouchableOpacity>
          <Text className="text-lg font-bold bg-[#6755A4] p-2 px-3 text-white">
            {item.quantity}
          </Text>
          <TouchableOpacity
            className="ml-2"
            onPress={() => updateCartQuantity(item.id, item.quantity + 1)}>
            <Text className="text-3xl text-[#6755A4] font-bold">+</Text>
          </TouchableOpacity>
        </View>
      </View>
      <TouchableOpacity onPress={() => handleRemoveFromCart(item.id)}>
        <CrossIcon name="circle-with-cross" size={35} color={'#6755A4'} />
      </TouchableOpacity>
    </View>
  );

  // total price
  const totalPrice = cartItems.reduce((acc, item) => acc + item.totalPrice, 0);

  // cart empty
  if (cartItems.length === 0) {
    return (
      <View className="flex-1 justify-center items-center">
        <Text className="text-[#6755A4] text-xl">Your cart is empty!</Text>
      </View>
    );
  }

  // saving bill
  const bill = {
    items: cartItems.map((item, index) => ({
      index: index + 1,
      title: item.Name,
      quantity: item.quantity,
      price: item.Unit_Price,
    })),
    totalPrice: totalPrice.toFixed(2),
    timestamp: new Date().toISOString(), // Include timestamp for storage
  };

  const saveBills = async () => {
    const cartBill = cartBills();

    if (isOnline) {
      await dispatch(
        cartData({products: cartBill, status: 'Save', businessId: userId}),
      );
    } else {
      dispatch(offlineCart(cartItems));
    }
    console.log('CART-------------------------->', cartBill);

    setTimeout(() => dispatch(clearCart()), 1000);
  };

  const printBills = async () => {
    await BluetoothEscposPrinter.printText('\r\n\r\n\r\n', {});
    await BluetoothEscposPrinter.ALIGN.CENTER;
    await BluetoothEscposPrinter.printPic(logo, {width: 250, left: 50});
    await BluetoothEscposPrinter.printText('\n\r', {});
    const currentDate = new Date();
    const dateFormatOptions = {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
    };
    const timeFormatOptions = {
      hour: '2-digit',
      minute: '2-digit',
    };

    const formattedDate = currentDate.toLocaleDateString(
      undefined,
      dateFormatOptions,
    );
    const formattedTime = currentDate.toLocaleTimeString(
      undefined,
      timeFormatOptions,
    );

    await BluetoothEscposPrinter.printText(
      `Date: ${formattedDate} ${formattedTime}\n\r`,
      {},
    );

    // Print line separating header and bill items...
    await BluetoothEscposPrinter.printText(
      '--------------------------------',
      {},
    );
    await BluetoothEscposPrinter.printText('\n\r', {});

    // Print column headers...
    let columnWidths = [6, 10, 5, 8];
    await BluetoothEscposPrinter.printColumn(
      columnWidths,
      [
        BluetoothEscposPrinter.ALIGN.LEFT,
        BluetoothEscposPrinter.ALIGN.LEFT,
        BluetoothEscposPrinter.ALIGN.CENTER,
        BluetoothEscposPrinter.ALIGN.RIGHT,
      ],
      ['Index', 'Items', 'Quan', 'Price'],
      {},
    );
    await BluetoothEscposPrinter.printText('\n\r', {});

    // Print cart items...
    cartItems.forEach((item, index) => {
      BluetoothEscposPrinter.printColumn(
        columnWidths,
        [
          BluetoothEscposPrinter.ALIGN.LEFT,
          BluetoothEscposPrinter.ALIGN.LEFT,
          BluetoothEscposPrinter.ALIGN.CENTER,
          BluetoothEscposPrinter.ALIGN.RIGHT,
        ],
        [
          (index + 1).toString(),
          item.Name,
          item.quantity.toString(),
          item.Unit_Price.toString(),
        ],
        {},
      );
      BluetoothEscposPrinter.printText('\n\r', {});
    });

    // Print line separating items and total bill...
    await BluetoothEscposPrinter.printText(
      '--------------------------------',
      {},
    );
    await BluetoothEscposPrinter.printText('\n\r', {});

    // Print total bill...
    let totalQuantity = cartItems.reduce((acc, item) => acc + item.quantity, 0);
    let totalPrice = cartItems.reduce(
      (acc, item) => acc + item.quantity * item.Unit_Price,
      0,
    );

    await BluetoothEscposPrinter.printColumn(
      [6, 10, 5, 8],
      [
        BluetoothEscposPrinter.ALIGN.LEFT,
        BluetoothEscposPrinter.ALIGN.LEFT,
        BluetoothEscposPrinter.ALIGN.CENTER,
        BluetoothEscposPrinter.ALIGN.RIGHT,
      ],
      ['Total', '', totalQuantity.toString(), totalPrice.toString()],
      {},
    );
    await BluetoothEscposPrinter.printText('\n\r', {});

    // line to separate thanks and bill
    await BluetoothEscposPrinter.printText(
      '--------------------------------',
      {},
    );
    await BluetoothEscposPrinter.printText('\n\r', {});
    await BluetoothEscposPrinter.printText('Thanks for visiting here.\n\r', {});
    await BluetoothEscposPrinter.printText('\n\r', {});
    // line to separate thanks and comp name
    await BluetoothEscposPrinter.printText(
      '--------------------------------',
      {},
    );
    await BluetoothEscposPrinter.printText('\n\r', {});
    await BluetoothEscposPrinter.printText(
      'Powered By @ DigitalParchi\n\r',
      {},
    );
    await BluetoothEscposPrinter.printText('\n\r', {});

    const cartBill = cartBills();
    // const flattenedBills = cartBill;
    await dispatch(
      cartData({products: cartBill, status: 'Print', businessId: userId}),
    );
    console.log('CART---------------------------->', cartBill);

    // clear cart
    setTimeout(() => dispatch(clearCart()), 2000),
      {
        encoding: 'GBK',
        codepage: 0,
        widthtimes: 0,
        heigthtimes: 0,
        fonttype: 1,
      };
  };

  const cartBills = () => {
    return cartItems.map((item, index) => ({
      id: item.id,
      Name: item.Name,
      Quantity: item.quantity,
      Price: item.Unit_Price,
    }));
  };

  return (
    <>
      <View className="flex-1">
        <FlatList
          data={cartItems}
          renderItem={renderCartItem}
          keyExtractor={item => item.id}
          className="my-3 mx-0 px-3 max-h-fit "
        />
        <View className="flex-row justify-between py-4 border-t border-gray-200 mx-3">
          <Text className="text-black text-lg">Total Amount:</Text>
          <Text className="text-[#6755A4] text-lg font-bold">
            Rs. {totalPrice.toFixed(2)}
          </Text>
        </View>
        {/* Touchable highlight for "Print Bill" and save bill only */}
        <View className="flex-row justify-between items-center">
          <TouchableOpacity
            className="bg-[#6755A4] px-4 py-2 rounded-md mt-4 mb-3 mx-3 flex-grow"
            onPress={printBills}>
            <Text className="text-lg font-bold text-white text-center">
              Print Bill
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            className="bg-[#6755A4] px-4 py-2 rounded-md mt-4 mb-3 mx-3 flex-grow"
            onPress={saveBills}>
            <Text className="text-lg font-bold text-white text-center">
              Save Bill
            </Text>
          </TouchableOpacity>
        </View>
      </View>
    </>
  );
};

export default Cart;
