import React, {useEffect, useState} from 'react';
import {
  StyleSheet,
  Text,
  View,
  FlatList,
  RefreshControl,
  ScrollView,
} from 'react-native';
import PieChart from 'react-native-pie-chart';
import {useSelector, useDispatch} from 'react-redux';
import {clearBills, fetchDashboardData} from '../Features/ParchiSlice';
import DropdownComponent from '../Components/Dropdown';
import {useFocusEffect} from '@react-navigation/native';

function Dashboard() {
  const [refreshing, setRefreshing] = useState(false);
  const dashboardData = useSelector(state => state.app.dashboardData);
  const {userId} = useSelector(state => state.pin);
  console.log('dash--->', dashboardData);
  const dispatch = useDispatch();
  const [selectedDropdownValue, setSelectedDropdownValue] = useState('today');

  const fetchDashboardDataForSelectedValue = async value => {
    try {
      setRefreshing(true); // Set refreshing to true when fetching new data

      // Dispatch action to clear existing data
      console.log('Clearing bills');
      dispatch(clearBills());

      // Convert the selected value into date ranges
      const {dateFrom, dateTo} = getDateRange(value);
      console.log(
        `Fetching dashboard data for ${value} from ${dateFrom} to ${dateTo}`,
      );

      // Fetch dashboard data based on the selected value
      await dispatch(
        fetchDashboardData({dateFrom, dateTo, businessID: userId}),
      );

      console.log('Fetch successful');
      setSelectedDropdownValue(value);
    } catch (error) {
      console.error('Error fetching dashboard data:', error);
    } finally {
      setRefreshing(false); // Stop refreshing indicator
    }
  };

  useEffect(() => {
    // Fetch dashboard data for the default value ('today') when the component mounts
    fetchDashboardDataForSelectedValue('today');
  }, []);

  useEffect(() => {
    // Fetch dashboard data when the selectedDropdownValue changes
    if (selectedDropdownValue !== 'today') {
      fetchDashboardDataForSelectedValue(selectedDropdownValue);
    }
  }, [selectedDropdownValue]);

  const getDateRange = value => {
    const today = new Date();
    let dateFrom;
    // let dateTo = today.toISOString().split('T')[0]; // Get today's date in 'YYYY-MM-DD' format
    const dateTo = `${today.getFullYear()}-${String(
      today.getMonth() + 1,
    ).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;
    switch (value) {
      case 'today':
        dateFrom = dateTo;
        break;
      case 'last7Days':
        const last7Days = new Date(today);
        last7Days.setDate(today.getDate() - 7);
        dateFrom = last7Days.toISOString().split('T')[0];
        break;
      case 'last30Days':
        const last30Days = new Date(today);
        last30Days.setDate(today.getDate() - 30);
        dateFrom = last30Days.toISOString().split('T')[0];
        break;
      default:
        dateFrom = dateTo;
        break;
    }

    return {dateFrom, dateTo};
  };

  const groupAndCalculateTotalPrice = data => {
    const groupedData = {};

    data.forEach(item => {
      const cartID = item.Cart_ID || 'default';

      if (!groupedData[cartID]) {
        // If the cartID is not in the groupedData, initialize it
        groupedData[cartID] = {
          items: [],
          totalPrice: 0,
        };
      }

      // Add the item to the items array for the respective cartID
      groupedData[cartID].items.push(item);

      // Update the totalPrice for the respective cartID
      groupedData[cartID].totalPrice += item.Price;
    });

    // Convert grouped data into an array
    const result = Object.values(groupedData);

    return result;
  };

  const widthAndHeight = 120;
  const series = [123, 321, 123];
  const sliceColor = ['#C608D1', '#2900A5', '#ff9100'];
  const itemDescription = [
    {title: 'Items', color: 'black', inventory: 'Available'},
    {title: 'Electronics', color: '#C608D1', inventory: 123},
    {title: 'Clothing', color: '#2900A5', inventory: 321},
    {title: 'Home', color: '#ff9100', inventory: 391},
  ];

  return (
    <View style={{flex: 1}}>
      {/* sales chart */}
      <ScrollView
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={() => setRefreshing(true)}
          />
        }>
        <View style={styles.container} className="bg-violet-200 p-5">
          <View className="flex flex-row justify-between items-center">
            <View>
              <Text style={styles.title}>Sales</Text>
              <PieChart
                widthAndHeight={widthAndHeight}
                series={series}
                sliceColor={sliceColor}
                coverRadius={0.45}
                coverFill={'#FFF'}
              />
            </View>
            <View className="mt-10">
              {itemDescription?.map((item, index) => (
                <View key={index}>
                  <View className="flex-row items-center">
                    <View>
                      <Text
                        className="mx-1"
                        style={{
                          backgroundColor: item.color,
                          color: item.color,
                          width: 15,
                          height: 10,
                        }}>
                        *
                      </Text>
                    </View>
                    <View>
                      <Text className="py-1 text-black font-medium">
                        {item.title}({item.inventory})
                      </Text>
                    </View>
                  </View>
                </View>
              ))}
            </View>
          </View>
        </View>

        {/* Display the list of printed bills */}
        <View className="bg-white p-3 flex-1">
          <View className="flex-row justify-between items-center">
            <Text className="text-black font-bold text-lg">Sales Report</Text>

            {/* drop down */}
            <View style={styles.dropdownContainer}>
              <DropdownComponent
                onDropdownChange={fetchDashboardDataForSelectedValue}
              />
            </View>
          </View>
          <View style={styles.Billscontainer} className="bg-gray-300 p-3">
            {dashboardData?.length > 0 ? (
              // Use FlatList to render dashboardData
              <FlatList
                data={groupAndCalculateTotalPrice(dashboardData)}
                keyExtractor={item => item.Cart_ID}
                renderItem={({item}) => (
                  <View className="bg-white shadow-lg shadow-gray-400 rounded-lg my-2 p-4">
                    {/* Display your grouped dashboard data here */}
                    <Text
                      className="text-black text-sm"
                      style={{fontWeight: 'bold', marginBottom: 15}}>
                      Date: {item.items[0].Date_Added}
                    </Text>
                    {item.items.map((groupedItem, index) => (
                      <View key={index}>
                        <View
                          style={{
                            flexDirection: 'row',
                            justifyContent: 'space-between',
                            marginBottom: 10,
                          }}>
                          <Text
                            className="text-black text-xl"
                            style={{
                              width: '70%',
                              fontSize: 16,
                              lineHeight: 19,
                            }}>
                            {groupedItem.PSid} ({groupedItem.Quantity})
                          </Text>
                          <Text
                            className="text-black text-lg"
                            style={{
                              width: '20%',
                              fontSize: 16,
                              alignSelf: 'flex-end',
                            }}>
                            {groupedItem.Price}/-
                          </Text>
                        </View>
                      </View>
                    ))}
                    <View className="flex-row justify-between items-center mt-2">
                      <Text className="text-black text-lg font-bold">
                        Total:
                      </Text>
                      <Text className="text-black text-lg font-bold">
                        Rs. {item.totalPrice}
                      </Text>
                    </View>
                  </View>
                )}
              />
            ) : (
              <Text className="mx-auto text-lg font-bold text-black">
                No data available
              </Text>
            )}
          </View>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    margin: 10,
    borderRadius: 10,
  },
  Billscontainer: {
    flexShrink: 1,
    marginBottom: 0,
    borderRadius: 10,
  },
  title: {
    fontSize: 24,
    margin: 10,
    fontWeight: 'bold',
    color: 'black',
  },
  rowContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  dropdownContainer: {
    flexShrink: 0,
    flex: 1,
  },
});

export default Dashboard;
