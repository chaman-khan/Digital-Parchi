import {createSlice, createAsyncThunk} from '@reduxjs/toolkit';

// all products
export const showData = createAsyncThunk(
  'showData',
  async (userId, {rejectWithValue}) => {
    try {
      const response = await fetch('https://parchi.maaqdocplus.com/products', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({Business_ID: userId}),
      });

      const result = await response.json();
      return result;
    } catch (error) {
      return rejectWithValue(error.response);
    }
  },
);

// cart data

export const cartData = createAsyncThunk(
  'saveBill',
  async ({businessId, products, status}, {rejectWithValue}) => {
    try {
      const response = await fetch('https://parchi.maaqdocplus.com/cart', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          Business_ID: businessId,
          products,
          Print_Status: status,
        }),
      });

      const result = await response.json();

      if (response.ok) {
        // The request was successful
        console.log('Response from backend:', result);
        return result;
      } else {
        // The request failed
        console.error(
          'Failed to save bill:',
          response.status,
          response.statusText,
        );
        return rejectWithValue(result);
      }
    } catch (error) {
      console.error('Error while saving bill:', error);
      return rejectWithValue(error.response);
    }
  },
);

// dashbaord Data

export const fetchDashboardData = createAsyncThunk(
  'fetchDashboardData',
  async ({dateFrom, dateTo, businessID}, {rejectWithValue}) => {
    try {
      const response = await fetch('https://parchi.maaqdocplus.com/dashboard', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({dateFrom, dateTo, Business_ID: businessID}),
      });

      const result = await response.json();
      return result;
    } catch (error) {
      return rejectWithValue(error.response);
    }
  },
);

// slice
const ParchiSlice = createSlice({
  name: 'app',
  initialState: {
    products: [],
    selectedProduct: null,
    loading: false,
    error: null,
    searchData: [],
    cartItems: [],
    offlineCartItems: [],
    printedBills: [],
    dashboardData: [],
  },
  reducers: {
    // Single Item Modal
    setSelectedProduct: (state, action) => {
      state.selectedProduct = action.payload;
    },

    // search Items
    searchItems: (state, action) => {
      state.searchData = action.payload;
    },

    // clear cart
    clearCart: state => {
      state.cartItems = [];
    },

    // clear bills
    clearBills: state => {
      state.printedBills = [];
    },

    offlineCart: (state, action) => {
      state.offlineCartItems = action.payload;
    },
    clearCartOffline: state => {
      state.offlineCartItems = [];
    },

    // Add to cart with quantity and total price
    addToCart: (state, action) => {
      const product = action.payload;
      const existingItem = state.cartItems.find(item => item.id === product.id);
      if (existingItem) {
        const updatedItem = {
          ...existingItem,
          quantity: existingItem.quantity + 1,
          totalPrice: existingItem.totalPrice + product.Unit_Price,
        };
        state.cartItems = state.cartItems.map(item =>
          item.id === existingItem.id ? updatedItem : item,
        );
      } else {
        state.cartItems.push({
          ...product,
          quantity: 1,
          totalPrice: product.Unit_Price,
        });
      }
    },

    // Remove from cart
    removeFromCart: (state, action) => {
      state.cartItems = state.cartItems.filter(
        item => item.id !== action.payload,
      );
    },

    // updating items quantity
    updateQuantity: (state, action) => {
      const {productId, quantity} = action.payload;
      const existingItem = state.cartItems.find(item => item.id === productId);
      if (existingItem) {
        const updatedItem = {
          ...existingItem,
          quantity,
          totalPrice: existingItem.Unit_Price * quantity,
        };
        state.cartItems = state.cartItems.map(item =>
          item.id === existingItem.id ? updatedItem : item,
        );
      }
    },
  },
  extraReducers: builder => {
    builder
      .addCase(showData.pending, state => {
        state.loading = true;
      })
      .addCase(showData.fulfilled, (state, action) => {
        state.loading = false;
        state.products = action.payload.products;
      })
      .addCase(showData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })
      .addCase(cartData.pending, state => {
        state.loading = true;
      })
      .addCase(cartData.fulfilled, (state, action) => {
        state.loading = false;
        console.log('Save bill successful:', action.payload);
      })
      .addCase(cartData.rejected, (state, action) => {
        state.loading = false;
        console.error('Save bill failed:', action.payload);
      })
      .addCase(fetchDashboardData.fulfilled, (state, action) => {
        state.dashboardData = action.payload.records;
      });
  },
});

export const {
  setSelectedProduct,
  addToCart,
  removeFromCart,
  searchItems,
  setActiveFilter,
  updateQuantity,
  clearCart,
  clearBills,
  cartItems,
  offlineCart,
  clearCartOffline,
} = ParchiSlice.actions;
export default ParchiSlice.reducer;
