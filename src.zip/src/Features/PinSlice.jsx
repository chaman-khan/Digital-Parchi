import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';

export const sendPin = createAsyncThunk('sendPin', async ({ phoneNumber, pinCode, Business_Name }, { rejectWithValue }) => {
  try {
    const response = await fetch('https://parchi.maaqdocplus.com/login', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ phone: phoneNumber.replace('+92', ''), password: pinCode, Business_Name}),
    });

    const result = await response.json();
    return result;
  } catch (error) {
    return rejectWithValue(error.message);
  }
});

const PinSlice = createSlice({
  name: 'pin',
  initialState: {
    userId:'',
    logo:'',
    loading: false,
    error: null,
  },
  extraReducers: (builder) => {
    builder
      .addCase(sendPin.pending, (state) => {
        state.loading = true;
      })
      .addCase(sendPin.fulfilled, (state, action) => {
        state.loading = false;
        console.log('PIN Sent:', action.payload);
        state.userId = action.payload.Business_ID;
        state.logo = action.payload.logo;
        console.log("id", action.payload.Business_ID);
      })
      .addCase(sendPin.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload ? action.payload.response : "An error occurred";
      });
  },
});

export default PinSlice.reducer;
