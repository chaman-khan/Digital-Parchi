import React from 'react';
import {createNativeStackNavigator} from '@react-navigation/native-stack';
import {createBottomTabNavigator} from '@react-navigation/bottom-tabs';
import {NavigationContainer} from '@react-navigation/native';
import SingleItem from '../Components/ItemModal';
import Cart from '../Screens/Cart';
import Dashboard from '../Screens/Dashboard';
import Home from '../Screens/Home';
import Login from '../Screens/Login';
import BookDemo from '../Screens/BookDemo';
import HomeIcon from 'react-native-vector-icons/AntDesign';
import CartIcon from 'react-native-vector-icons/AntDesign';
import DashboardIcon from 'react-native-vector-icons/AntDesign';
import UserIcon from 'react-native-vector-icons/AntDesign';
import Bluetooth from '../Screens/Bluetooth';
import BluetoothIcon from 'react-native-vector-icons/FontAwesome';
import {Text, View} from 'react-native';

import {useSelector} from 'react-redux';
import Account from '../Screens/Account';
import InventoryManagement from '../Screens/InventoryManagement';
import EditScreen from '../Screens/editScreen';
import AddProduct from '../Screens/AddProduct';

const MainNav = () => {
  const Stack = createNativeStackNavigator();
  const Tab = createBottomTabNavigator();
  const cartItems = useSelector(state => state.app.cartItems);

  const {userId} = useSelector(state => state.pin);

  const CustomHeaderTitle = () => (
    <Text style={{fontSize: 18, fontWeight: 'bold', color: 'white'}}>
      Demo Store
    </Text>
  );

  // bottom navigator
  const HomeTabs = () => (
    <Tab.Navigator
      screenOptions={{
        tabBarActiveTintColor: '#6755A4',
        tabBarInactiveTintColor: 'grey',
        tabBarLabelStyle: {fontSize: 14},
        tabBarStyle: {
          paddingTop: 10,
          paddingBottom: 10,
          height: 70,
          borderTopLeftRadius: 25,
          borderTopRightRadius: 25,
        },
        headerStyle: {backgroundColor: '#6755A4'},
        headerTitle: CustomHeaderTitle,
        headerTitleStyle: {color: 'white'},
        headerTitleAlign: 'center',
      }}>
      <Tab.Screen
        name="Home"
        component={Home}
        options={{
          tabBarIcon: ({color, size}) => (
            <HomeIcon name="home" size={size + 5} color={color} />
          ),
        }}
      />
      <Tab.Screen
        name="Dashboard"
        component={Dashboard}
        options={{
          tabBarIcon: ({color, size}) => (
            <DashboardIcon name="dashboard" size={size} color={color} />
          ),
        }}
      />
      <Tab.Screen
        name="Cart"
        component={Cart}
        options={{
          tabBarIcon: ({color, size}) => (
            <View>
              <CartIcon name="shoppingcart" size={size} color={color} />
              {cartItems != 0 && (
                <View
                  style={{
                    position: 'absolute',
                    backgroundColor: '#6755A4',
                    width: 20,
                    height: 20,
                    borderRadius: 10,
                    marginLeft: 15,
                    marginTop: -10,
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}>
                  <Text style={{color: 'white'}}>{cartItems.length}</Text>
                </View>
              )}
            </View>
          ),
        }}
      />
      <Tab.Screen
        name="Bluetooth"
        component={Bluetooth}
        options={{
          tabBarIcon: ({color, size}) => (
            <BluetoothIcon name="bluetooth" size={size} color={color} />
          ),
        }}
      />
      <Tab.Screen
        name="Account"
        component={Account}
        options={{
          tabBarIcon: ({color, size}) => (
            <UserIcon name="user" color={color} size={size} />
          ),
          headerShown: false,
          // tabBarStyle: {display: 'none'},
        }}
      />
    </Tab.Navigator>
  );

  return (
    <NavigationContainer>
      <Stack.Navigator
        initialRouteName={userId !== '' ? 'Home' : 'Login Page'}
        screenOptions={{
          headerShown: false,
          headerStyle: {backgroundColor: '#6755A4'},
          headerTitleStyle: {color: 'white'},
          statusBarHidden: true,
          orientation: 'portrait',
        }}>
        <Stack.Screen
          name="Login Page"
          component={Login}
          options={{headerShown: false}}
        />
        <Stack.Screen
          name="Demo"
          component={BookDemo}
          options={{headerShown: false}}
        />
        <Stack.Screen name="Product Details" component={SingleItem} />
        <Stack.Screen
          name="Home"
          options={{headerShown: false}}
          component={HomeTabs}
        />
        <Stack.Screen
          name="InventoryManagement"
          // options={{headerShown: false}}
          component={InventoryManagement}
        />
        <Stack.Screen
          name="EditScreen"
          // options={{headerShown: false}}
          component={EditScreen}
        />
        <Stack.Screen
          name="AddProduct"
          // options={{headerShown: false}}
          component={AddProduct}
        />
      </Stack.Navigator>
    </NavigationContainer>
  );
};

export default MainNav;
