// import React, { useState } from 'react';
// import { StyleSheet, View } from 'react-native';
// import { Dropdown } from 'react-native-element-dropdown';

// const data = [
//   { label: 'today', value: 'today' },
//   { label: 'last 7 Days', value: 'last 7 Days' },
//   { label: 'last 30 Days', value: 'last 30 Days' },
// ];

// const DropdownComponent = () => {
//   const [value, setValue] = useState(null);
//   const [isFocus, setIsFocus] = useState(false);

//   return (
//     <View style={styles.container}>
//       <Dropdown
//         style={[styles.dropdown, isFocus && { borderColor: 'violet' }]}
//         selectedTextStyle={styles.selectedTextStyle}
//         iconStyle={styles.iconStyle}
//         data={data}
//         maxHeight={300}
//         labelField="label"
//         valueField="value"
//         value={value}
//         onFocus={() => setIsFocus(true)}
//         onBlur={() => setIsFocus(false)}
//         onChange={(item) => {
//           setValue(item.value);
//           setIsFocus(false);
//         }}
//         itemTextStyle = {styles.itemText}
//       />
//     </View>
//   );
// };

// const styles = StyleSheet.create({
//   container: {
//     marginVertical: 10,
//   },
//   dropdown: {
//     height: 50,
//     width: '80%',
//     alignSelf:'flex-end',
//     borderColor: 'black',
//     borderWidth: 0.5,
//     borderRadius: 8,
//     paddingHorizontal: 8,
//     color:'black',
//   },
//   selectedTextStyle: {
//     fontSize: 16,
//     color:'black'
//   },
//   iconStyle: {
//     width: 20,
//     height: 20,
//   },
// itemText:{
//   color:'black'
// }
// });

// export default DropdownComponent;

// DropdownComponent.jsx

import React, { useState, useEffect } from 'react';
import { StyleSheet, View } from 'react-native';
import { Dropdown } from 'react-native-element-dropdown';

const data = [
  { label: 'Today', value: 'today' },
  { label: 'Weekly', value: 'last7Days' },
  { label: 'Monthly', value: 'last30Days' },
];

const DropdownComponent = ({ onDropdownChange }) => {
  const [value, setValue] = useState(null);
  const [isFocus, setIsFocus] = useState(false);

  const handleDropdownChange = (item) => {
    setValue(item.value);
    setIsFocus(false);
    // Pass the selected value to the parent component
    onDropdownChange(item.value);
  };

  return (
    <View style={styles.container}>
      <Dropdown
        style={[styles.dropdown, isFocus && { borderColor: 'violet' }]}
        selectedTextStyle={styles.selectedTextStyle}
        iconStyle={styles.iconStyle}
        data={data}
        maxHeight={300}
        labelField="label"
        valueField="value"
        value={value}
        onFocus={() => setIsFocus(true)}
        onBlur={() => setIsFocus(false)}
        onChange={handleDropdownChange}
        itemTextStyle={styles.itemText}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    marginVertical: 10,
  },
  dropdown: {
    height: 50,
    width: '80%',
    alignSelf: 'flex-end',
    borderColor: 'black',
    borderWidth: 0.5,
    borderRadius: 8,
    paddingHorizontal: 8,
    color: 'black',
  },
  selectedTextStyle: {
    fontSize: 16,
    color: 'black',
  },
  
  iconStyle: {
    width: 20,
    height: 20,
  },
  itemText:{
      color:'black'
    }
});

export default DropdownComponent;
