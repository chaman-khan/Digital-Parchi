import React, {useState} from 'react';
import {View} from 'react-native';
import {Searchbar} from 'react-native-paper';

function Search({search}) {
  const [searchTerm, setSearchTerm] = useState('');

  const handleSearchChange = text => {
    setSearchTerm(text);
    search(text);
  };

  return (
    <View className="m-2">
      <Searchbar
        placeholder="Search"
        onChangeText={handleSearchChange}
        value={searchTerm}
        className="bg-gray-200 mx-auto shadow-2xl"
      />
    </View>
  );
}

export default Search;
